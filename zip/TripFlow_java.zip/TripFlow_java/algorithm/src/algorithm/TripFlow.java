package algorithm;

import input.Input;

/*海外旅行に行くまでのフローチャート*/

public class TripFlow{

  public static void main(String[] args){

	  String answer = null;

	  answer = Input.getString("自分で航空券や日程を申し込めるか？");
	  if("N".equals(answer.toUpperCase())) {
		  askTravelAgency();
	  }
	  
	  while(true) {
		  researchWeb();
		  answer = Input.getString("調べた地域で大丈夫(地域など)そうか？");
		  if("N".equals(answer.toUpperCase())) {
			  continue;
		  }		  
		  answer = Input.getString("航空券の値段は適切か？");
		  if("N".equals(answer.toUpperCase())) {
			  continue;
		  }
		  answer = Input.getString("航空券の日程は適切か？");
		  if("N".equals(answer.toUpperCase())) {
			  continue;
		  }
		  else
			  break;
	  }
	  System.out.println("往復の航空券を予約し購入した！");
	  System.out.println("-----------------------------");
	  
	  System.out.println("具体的に渡航先で観光したい観光地を探す。");
	  
	  answer = Input.getString("適切な観光地は見つかったか？(距離・所要時間・料金)");
	  if("N".equals(answer.toUpperCase())) {
  	  System.out.println("友人に相談し教えてもらう。");
	  }

	  System.out.println("webでホテルを探す");
	  
	  answer = Input.getString("値段は適切か？");
	  if("N".equals(answer.toUpperCase())) {
		  System.out.println("値段の適切な場所を他のサイトで探す。");
	  }
	  
	  answer = Input.getString("衛生面はどうか？");
	  if("N".equals(answer.toUpperCase())) {
		  System.out.println("衛生面が適切な場所を別のサイトで探す。");
	  }
	  
	  answer = Input.getString("食事つきか？");
	  if("N".equals(answer.toUpperCase())) {
		  System.out.println("周囲のレストランやスーパーマーケットを探す。");
	  }
	  System.out.println("ホテルの予約完了！");
	  System.out.println("----------");

	  /* ②空港内でのフロー*/
	  
	  System.out.println("出発日当日");
	  System.out.println("空港に向かう");

	  answer = Input.getString("当該のチェックインカウンターまで来れたか？");
	  if("N".equals(answer.toUpperCase())) {
		  System.out.println("インフォメーションカウンターへ行き、場所を確認する。");
	  }

	  System.out.println("チェックインする");
	  
	  answer = Input.getString("機内に持ち込めない荷物はないか？");
	  if("N".equals(answer.toUpperCase())) {
		  System.out.println("処分する。");
	  }
	  System.out.println("保安検査場を通過する");
	  System.out.println("搭乗口へ進む");
	  System.out.println("搭乗完了！");
  }

 public static void askTravelAgency() {
	 System.out.println("JTBやHISなどの旅行代理店に依頼する。");
 }

 public static void researchWeb() {
	 System.out.println("webで行きたい地域を調べる。");
 }


}